# PDF Viewer — Option B (Google Drive → Cloudflare Worker → GitHub Pages)

**เอกสาร:** `ผลงานนวัตกรรม ววน.pdf` (ขนาด ~91.7 MB)

เว็บ GitHub Pages: https://focus-os-2026.github.io/pdf-viewer/?page=4

## ทำไมเปลี่ยนจาก Apps Script

Apps Script ตัวเดิมอ่านและแปลงไฟล์ทั้งหมดเป็น Base64 ซึ่งไม่เหมาะกับไฟล์ใหญ่ 91.7 MB. ชุดใหม่นี้ใช้ Google Drive API และ HTTP `Range` ส่งข้อมูลเป็นช่วงผ่าน Cloudflare Worker แบบสตรีม โดยไม่ต้องเก็บ PDF บน GitHub.

## 1. Google Cloud

1. เปิด https://console.cloud.google.com/ แล้วสร้าง/เลือก Project.
2. ไปที่ **APIs & Services → Library**, เปิด **Google Drive API**.
3. ไปที่ **IAM & Admin → Service Accounts** สร้าง Service Account เช่น `pdf-viewer-reader`.
4. สร้าง **JSON Key** สำหรับ Service Account (ถ้านโยบายองค์กรอนุญาต). **ห้ามเผยแพร่ JSON Key** หรือ commit เข้า GitHub. ถ้านโยบายห้ามสร้าง key ให้ใช้วิธีจัดการตัวตนแบบไม่มีคีย์แทน ซึ่งต้องปรับ Worker เพิ่ม.
5. แชร์เฉพาะไฟล์ `ผลงานนวัตกรรม ววน.pdf` ใน Google Drive ให้ `client_email` ใน JSON เป็น **Viewer**.
6. แนะนำให้ใช้บัญชี/โปรเจกต์องค์กรที่อนุมัติการเผยแพร่เอกสารนี้แล้ว เพราะ Worker จะเผยแพร่ PDF ให้ทุกคนที่มีลิงก์.

## 2. Cloudflare Worker

1. เข้า https://dash.cloudflare.com/ → Workers & Pages → Create → Worker.
2. เปิด **Edit code**, แทนที่โค้ดทั้งหมดด้วยไฟล์ `cloudflare-worker/worker.js` แล้ว Deploy.
3. ไปที่ Settings → Variables and Secrets:
   - **Secret** ชื่อ `SERVICE_ACCOUNT_JSON`: วาง **เนื้อหาทั้งหมด** ของไฟล์ JSON Key ของ Service Account.
   - **Text variable** ชื่อ `ALLOWED_ORIGIN` = `https://focus-os-2026.github.io`
4. ถ้าปรับ Variables / Secrets แล้วต้อง Deploy / เปิดเวอร์ชันที่ตั้งค่าใหม่ให้ทำงาน.
5. นำ Worker URL เช่น `https://pdf-drive.example.workers.dev` มาเติม `/pdf`.
6. ทดลองเปิด `https://...workers.dev/pdf` ใน Browser ควรเห็น PDF หรือระบบดาวน์โหลด (ขนาดไฟล์ใหญ่).

**หมายเหตุ:** Cloudflare Worker ให้บริการไฟล์แบบสาธารณะเมื่อใช้ URL ถูกต้อง; CORS ป้องกันการอ่านจากเว็บอื่นตามนโยบายเบราว์เซอร์ แต่ **ไม่ใช่การป้องกันการเข้าถึงไฟล์**. Worker ไม่ใช่ระบบจัดการสิทธิ์ผู้ใช้งาน.

## 3. GitHub Pages

1. เปิด `index.html` แล้วหาบรรทัด `const PDF_API_URL = '';`.
2. ใส่ Worker URL ที่ลงท้ายด้วย `/pdf` เช่น `const PDF_API_URL = 'https://pdf-drive.example.workers.dev/pdf';`
3. อัปโหลดทับ `index.html` ใน Repository `Focus-os-2026/pdf-viewer` (branch `main`). ไม่ต้องอัปโหลด PDF ไปยัง GitHub.
4. หลัง Deploy GitHub Pages ทดสอบ `https://focus-os-2026.github.io/pdf-viewer/?page=4` พร้อมปุ่มเลื่อนหน้าและมือถือ.

## 4. อัปเดต PDF

Google Drive → คลิกขวาไฟล์เดิม → File information → Manage versions → Upload new version เพื่อ **รักษา File ID เดิม**. Worker อ้างอิง File ID เดิม จึงไม่ต้องเปลี่ยน QR Code. อาจต้องรีเฟรชหน้าเว็บเพื่อดึงข้อมูลใหม่.

## ตรวจสอบเมื่อเกิดปัญหา

- **Worker 403 / 404:** Google Drive API ไม่เปิดใช้งาน หรือ Service Account ยังไม่ได้รับสิทธิ์อ่าน PDF.
- **Worker 502:** ตรวจ Worker Logs และ Secret `SERVICE_ACCOUNT_JSON`.
- **PDF.js error / blank:** ตรวจ `PDF_API_URL`, CORS, Response `206` และ `Content-Range` ผ่าน Network tab.
- **PDF หลายหน้าโหลดช้า:** เป็นผลจากขนาดไฟล์และเครือข่าย; ระบบไม่รับประกันการโหลดทุกหน้าอย่างทันที.
- **ความปลอดภัย:** อย่าอัปโหลด service account JSON key เข้าบทสนทนา/Repository; ใส่ใน Cloudflare Secret เท่านั้น.

## สถานะ

ยังไม่ได้ Deploy Worker หรือทดสอบไฟล์จริง. ต้องทดสอบการโหลดหน้า 4 และการเปลี่ยนหน้าก่อนพิมพ์ QR Code ใน Canva.

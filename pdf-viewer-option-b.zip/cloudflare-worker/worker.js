/**
 * Streaming Google Drive PDF proxy for Cloudflare Workers.
 * Share the PDF with the service account email as Viewer.
 * Set SERVICE_ACCOUNT_JSON as a Worker Secret (never commit it to GitHub).
 * Set ALLOWED_ORIGIN as plain text Worker Variable: https://focus-os-2026.github.io
 * Fixed file ID means callers cannot access other files.
 */
const FILE_ID = '1cPw_QqntEvepwkR0Bbyx1VZR6Y4qtAav';
const DRIVE_SCOPE = 'https://www.googleapis.com/auth/drive.readonly';
const TOKEN_ENDPOINT = 'https://oauth2.googleapis.com/token';
const encoder = new TextEncoder();
let tokenCache = null;

function base64Url(bytes) {
  let str = '';
  for (const byte of bytes) str += String.fromCharCode(byte);
  return btoa(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

function pemToArrayBuffer(pem) {
  const body = pem.replace(/-----BEGIN PRIVATE KEY-----|-----END PRIVATE KEY-----|\s/g, '');
  const binary = atob(body);
  return Uint8Array.from(binary, c => c.charCodeAt(0)).buffer;
}

async function getAccessToken(env) {
  if (tokenCache && tokenCache.expires > Date.now() + 60000) return tokenCache.value;
  if (!env.SERVICE_ACCOUNT_JSON) throw new Error('Worker secret SERVICE_ACCOUNT_JSON missing');
  const sa = JSON.parse(env.SERVICE_ACCOUNT_JSON);
  if (!sa.client_email || !sa.private_key) throw new Error('Invalid service account JSON');
  const now = Math.floor(Date.now() / 1000);
  const header = base64Url(encoder.encode(JSON.stringify({ alg: 'RS256', typ: 'JWT' })));
  const payload = base64Url(encoder.encode(JSON.stringify({
    iss: sa.client_email, scope: DRIVE_SCOPE, aud: TOKEN_ENDPOINT,
    iat: now, exp: now + 3600
  })));
  const key = await crypto.subtle.importKey(
    'pkcs8', pemToArrayBuffer(sa.private_key),
    { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['sign']
  );
  const signature = await crypto.subtle.sign('RSASSA-PKCS1-v1_5', key, encoder.encode(`${header}.${payload}`));
  const assertion = `${header}.${payload}.${base64Url(new Uint8Array(signature))}`;
  const res = await fetch(TOKEN_ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion
    })
  });
  if (!res.ok) throw new Error(`Google OAuth returned ${res.status}`);
  const data = await res.json();
  tokenCache = { value: data.access_token, expires: Date.now() + (data.expires_in || 3600) * 1000 };
  return data.access_token;
}

function cors(origin) {
  return {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
    'Access-Control-Allow-Headers': 'Range, Content-Type',
    'Access-Control-Expose-Headers': 'Accept-Ranges, Content-Range, Content-Length, Content-Type, ETag',
    'Vary': 'Origin',
  };
}

export default {
  async fetch(request, env) {
    const origin = env.ALLOWED_ORIGIN || 'https://focus-os-2026.github.io';
    const headers = cors(origin);
    const url = new URL(request.url);
    if (url.pathname !== '/pdf') return new Response('Not found', { status: 404, headers });
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers });
    if (!['GET','HEAD'].includes(request.method)) return new Response('Method not allowed', { status: 405, headers });
    try {
      const accessToken = await getAccessToken(env);
      const incomingRange = request.headers.get('Range');
      // Google supports a single byte range, not multipart ranges.
      if (incomingRange && !/^bytes=\d+-\d*$/.test(incomingRange)) {
        return new Response('Invalid Range', { status: 416, headers });
      }
      const driveUrl = `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(FILE_ID)}?alt=media`;
      const upstreamHeaders = new Headers({ 'Authorization': `Bearer ${accessToken}` });
      if (incomingRange) upstreamHeaders.set('Range', incomingRange);
      const upstream = await fetch(driveUrl, {
        method: request.method,
        headers: upstreamHeaders,
        redirect: 'follow',
        cache: 'no-store'
      });
      if (!upstream.ok && upstream.status !== 206) {
        return new Response(`Google Drive API HTTP ${upstream.status}. Check file sharing and API access.`,
          { status: upstream.status, headers });
      }
      const outputHeaders = new Headers(headers);
      for (const name of ['Content-Type','Content-Length','Content-Range','Accept-Ranges','ETag']) {
        const value = upstream.headers.get(name);
        if (value) outputHeaders.set(name, value);
      }
      outputHeaders.set('Content-Type', 'application/pdf');
      outputHeaders.set('Content-Disposition', 'inline; filename="document.pdf"');
      outputHeaders.set('Cache-Control', 'no-store, max-age=0');
      outputHeaders.set('Accept-Ranges', 'bytes');
      // Streams the upstream response: never buffer the entire PDF into Worker memory.
      return new Response(request.method === 'HEAD' ? null : upstream.body, {
        status: upstream.status, headers: outputHeaders
      });
    } catch (err) {
      console.error('Drive proxy failed:', err?.message);
      return new Response('PDF proxy error. Check Worker configuration and logs.',
        { status: 502, headers });
    }
  }
};
